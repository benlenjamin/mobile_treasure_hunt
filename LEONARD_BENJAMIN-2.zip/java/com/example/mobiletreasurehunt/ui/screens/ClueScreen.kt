package com.example.mobiletreasurehunt.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mobiletreasurehunt.viewmodel.THViewModel
import java.util.concurrent.TimeUnit

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

@Composable
fun ClueScreen(
    viewModel: THViewModel
) {
    val currClueIndex by viewModel.currClueIndex.collectAsStateWithLifecycle()
    val clues by viewModel.clues.collectAsStateWithLifecycle()
    val timer by viewModel.timer.collectAsStateWithLifecycle()
    val showHint by viewModel.showHint.collectAsStateWithLifecycle()
    val showLocIncorrectPopup by viewModel.showLocIncorrectPopup.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val currClue = clues.getOrNull(currClueIndex)

    if (currClue == null) {
        Text(
            text = "Error: Clue not found properly.",
            modifier = Modifier.fillMaxSize(),
            textAlign = TextAlign.Center
        )
        LaunchedEffect(Unit) {
            viewModel.returnHome()
        }
        return
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatTime(timer),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Text(
                text = currClue.clueText,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f).padding(bottom = 16.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = { viewModel.showHint()}) {
                    Text("Hint")
                }
                Button(onClick = {viewModel.foundIt(context)}) {
                    Text("Found It!")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(onClick = {viewModel.quitGame()}, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Quit Mobile Treasure Hunt"
                )
            }
        }

        if (showHint) {
            AlertDialog(
                onDismissRequest = {viewModel.hideHint()},
                title = { Text("Hint")},
                text = { Text(currClue.clueHint)},
                confirmButton = {
                    TextButton(onClick = { viewModel.hideHint()}) {
                        Text("Understood.")
                    }
                }
            )
        }

        if (showLocIncorrectPopup) {
            LaunchedEffect(snackbarHostState) {
                snackbarHostState.showSnackbar("Incorrect", withDismissAction = true)
                viewModel.onLocIncorrectPopupDismissed()
            }
        }
        SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
    }
}


@Composable
fun formatTime(tempTime: Long): String {
    val mins = TimeUnit.MILLISECONDS.toMinutes(tempTime)
    val secs = TimeUnit.MILLISECONDS.toSeconds(tempTime) - TimeUnit.MINUTES.toSeconds(mins)

    return String.format("%02d:%02d", mins, secs)
}