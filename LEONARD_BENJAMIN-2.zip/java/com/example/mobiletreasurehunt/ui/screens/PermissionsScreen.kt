package com.example.mobiletreasurehunt.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.example.mobiletreasurehunt.viewmodel.THViewModel
import com.google.android.gms.common.api.GoogleApi
import android.provider.Settings
import androidx.lifecycle.viewmodel.compose.viewModel

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

@Composable
fun PermissionsScreen(
    viewModel: THViewModel = viewModel(),
    onNavigateToStart: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var foregroundLocGranted by remember {mutableStateOf(false)}

    val foregroundPerms = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )

    val backgroundSettingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        val allGranted = hasAllPermissions(context, foregroundPerms, true)
        viewModel.onPermissionResult(allGranted)
    }

    val foregroundPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val fineLocGranted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseLocGranted = perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        foregroundLocGranted = fineLocGranted || coarseLocGranted

        if (foregroundLocGranted) {
            if (!hasBackgroundLocationPermission(context)) {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                }
                backgroundSettingsLauncher.launch(intent)
            } else {
                viewModel.onPermissionResult(true)
            }
        } else {
            viewModel.onPermissionResult(false)
        }
    }
    //val requiredPerms = mutableListOf(
    //    Manifest.permission.ACCESS_FINE_LOCATION,
    //    Manifest.permission.ACCESS_COARSE_LOCATION
    //).apply {
    //    add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    //}.toTypedArray()
    //val requiredPerms = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    //val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
    //    val foregroundGranted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true || perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true

    //    val backgroundGranted = perms[Manifest.permission.ACCESS_BACKGROUND_LOCATION] == true

    //    val allGranted = foregroundGranted && backgroundGranted
    //    viewModel.onPermissionResult(allGranted)
    //}

    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            val allGranted = hasAllPermissions(context, foregroundPerms, true)
            viewModel.onPermissionResult(allGranted)
        }
    }

    val permsGranted by viewModel.permsGranted.collectAsStateWithLifecycle()

    LaunchedEffect(permsGranted) {
        if (permsGranted){
            onNavigateToStart()
        }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Location Permissions Needed",
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Text(
            text = "The Mobile Treasure Hunt depends on your location." +
                "You must select Permissions/Location and Choose Allow all the time",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Button(
            onClick = {
                foregroundPermLauncher.launch(foregroundPerms)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Grant Location Perms")
        }
    }
}

fun hasAllPermissions(context: Context, foregroundPerms: Array<String>, checkBackground: Boolean): Boolean {
    val foregroundGranted = hasForegroundPerm(context)

    return if (checkBackground) {
        foregroundGranted && hasBackgroundLocationPermission(context)
    } else {
        foregroundGranted
    }
}

fun hasForegroundPerm(context: Context): Boolean {
    return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
}

fun hasBackgroundLocationPermission(context: Context): Boolean {
    return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
}
