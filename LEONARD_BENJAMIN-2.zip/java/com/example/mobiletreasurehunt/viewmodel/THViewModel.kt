package com.example.mobiletreasurehunt.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mobiletreasurehunt.data.model.Clue
import com.example.mobiletreasurehunt.data.repository.TreasureHuntRepository
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.delay

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

class THViewModel(application: Application) : AndroidViewModel(application){
    private val _clues = MutableStateFlow<List<Clue>>(emptyList())
    val clues: StateFlow<List<Clue>> = _clues.asStateFlow()

    private val _currClueIndex = MutableStateFlow(0)
    val currClueIndex: StateFlow<Int> = _currClueIndex.asStateFlow()

    private val _timer = MutableStateFlow(0L)
    val timer: StateFlow<Long> = _timer.asStateFlow()

    //ticking = timer counting
    private val _ticking = MutableStateFlow(false)
    val ticking: StateFlow<Boolean> = _ticking.asStateFlow()

    private val _permsGranted = MutableStateFlow(false)
    val permsGranted: StateFlow<Boolean> = _permsGranted.asStateFlow()

    private val _showHint = MutableStateFlow(false)
    val showHint: StateFlow<Boolean> = _showHint.asStateFlow()

    private val _showLocIncorrectPopup = MutableStateFlow(false)
    val showLocIncorrectPopup: StateFlow<Boolean> = _showLocIncorrectPopup.asStateFlow()

    private val _navEvent = MutableStateFlow<NavigationEvent?>(null)
    val navEvent: StateFlow<NavigationEvent?> = _navEvent.asStateFlow()

    ////////////////
    private val _lastKnownLocation = MutableStateFlow<android.location.Location?>(null)
    val lastKnownLocation: StateFlow<android.location.Location?> = _lastKnownLocation.asStateFlow()
    /////////////////////
    private var timerJob: Job? = null
    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(application)
    private val locationRequest = com.google.android.gms.location.LocationRequest.Builder(10000)
        .setPriority(com.google.android.gms.location.LocationRequest.PRIORITY_HIGH_ACCURACY)
        .setMinUpdateIntervalMillis(500L)
        .build()
    private val locationCallback = object : com.google.android.gms.location.LocationCallback() {
        override fun onLocationResult(locationResult: com.google.android.gms.location.LocationResult) {
            locationResult.lastLocation?.let { newLocation ->
                _lastKnownLocation.value = newLocation
            }
        }
    }


    //Init
    init {
        _clues.value = TreasureHuntRepository.loadCluesFromJson(application.applicationContext)
    }

    fun startGame() {
        _currClueIndex.value = 0
        _timer.value = 0L
        _ticking.value = true
        startTimer()
        _navEvent.value = NavigationEvent.NavigateToClue
    }

    fun resumeGame() {
        _ticking.value = true
        startTimer()
        _showHint.value = false
        _navEvent.value = NavigationEvent.NavigateToClue
    }

    fun pauseGame() {
        _ticking.value = false
        timerJob?.cancel()
    }

    fun quitGame() {
        pauseGame()
        _navEvent.value = NavigationEvent.NavigateToStart
    }

    fun showHint() {
        _showHint.value = true
    }

    fun hideHint() {
        _showHint.value = false
    }

    fun foundIt(context: Context) {
        viewModelScope.launch {
            if (checkLocation(context)) {
                _showLocIncorrectPopup.value = false
                pauseGame()

                if (_currClueIndex.value < _clues.value.size -1) {
                    _navEvent.value = NavigationEvent.NavigateToClueSolved
                }
                else {
                    _navEvent.value = NavigationEvent.NavigateToTHCompleted
                }
            } else {
                _showLocIncorrectPopup.value = true
            }
        }
    }

    fun nextClue() {
        _navEvent.value = NavigationEvent.NavigateToClue

        viewModelScope.launch {
            delay(10L)

            _currClueIndex.value++
            _ticking.value = true
            startTimer()
        }
    }

    fun returnHome() {
        pauseGame()
        _navEvent.value = NavigationEvent.NavigateToStart
    }

    //perms
    fun onPermissionResult(granted: Boolean) {
        _permsGranted.value = granted
        if (granted == true) {
            startLocationUpdates()
        } else {
            stopLocationUpdates()
        }
    }

    private fun startLocationUpdates() {
        try {
            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null)
        } catch (e: SecurityException) {
            _permsGranted.value = false
        }
    }

    private fun stopLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    private fun checkLocation(context: Context): Boolean {
        val tempClue = _clues.value.getOrNull(_currClueIndex.value) ?: return false
        val tempLatitude = tempClue.clueLocation.locLatitude
        val tempLongitude = tempClue.clueLocation.locLongitude

        val currLoc = _lastKnownLocation.value ?: return false

        val dist = calculateHaversineDistance(
            currLoc.latitude,
            currLoc.longitude,
            tempLatitude,
            tempLongitude
        )

        val tol = 10.0
        return dist <= tol
    }

    private fun calculateHaversineDistance(
        lat1: Double,
        long1: Double,
        lat2: Double,
        long2: Double
    ): Double {
        val earthR = 6371e3
        val phi1 = Math.toRadians(lat1)
        val phi2 = Math.toRadians(lat2)
        val deltaPhi = Math.toRadians(lat2 - lat1)
        val deltaLambda = Math.toRadians(long2 - long1)

        val a = sin(deltaPhi / 2) * sin(deltaPhi / 2) +
                cos(phi1) * cos(phi2) *
                sin(deltaLambda / 2) * sin(deltaLambda / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))

        return earthR * c
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_ticking.value == true) {
                delay(1000)
                _timer.value += 1000
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        stopLocationUpdates()

    }

    fun onNavigationEventHandled() {
        _navEvent.value = null
    }

    fun onLocIncorrectPopupDismissed() {
        _showLocIncorrectPopup.value = false
    }
}

sealed class NavigationEvent {
    object NavigateToStart : NavigationEvent()
    object NavigateToClue : NavigationEvent()
    object NavigateToClueSolved : NavigationEvent()
    object NavigateToTHCompleted : NavigationEvent()
}