package com.example.mobiletreasurehunt.data.repository

import android.content.Context
import com.example.mobiletreasurehunt.R
import com.example.mobiletreasurehunt.data.model.Clue
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

object TreasureHuntRepository {
    fun loadCluesFromJson(context: Context): List<Clue> {
        val jsonString: String
        try {
            val inputStream = context.resources.openRawResource(R.raw.mth_data)
            jsonString = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use {it.readText()}
        } catch (ioException: IOException) {
            ioException.printStackTrace()
            return emptyList()
        }

        return Json.decodeFromString(jsonString)
    }
}