package com.example.mobiletreasurehunt.data.model
import kotlinx.serialization.Serializable

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

@Serializable
data class Clue(
    val clueID: Int,
    val clueText: String,
    val clueHint: String,
    val clueLocation: Location,
    val clueInfo: String
)
