package com.example.mobiletreasurehunt.data.model
import kotlinx.serialization.Serializable

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

@Serializable
data class Location(
    val locLatitude: Double,
    val locLongitude: Double,
    val locName: String
)