package com.example.mobiletreasurehunt.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.mobiletreasurehunt.ui.screens.ClueScreen
import com.example.mobiletreasurehunt.ui.screens.FoundItScreen
import com.example.mobiletreasurehunt.ui.screens.PermissionsScreen
import com.example.mobiletreasurehunt.ui.screens.StartScreen
import com.example.mobiletreasurehunt.ui.screens.VictoryScreen
import com.example.mobiletreasurehunt.viewmodel.NavigationEvent
import com.example.mobiletreasurehunt.viewmodel.THViewModel

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

@Composable
fun TreasureHuntNavGraph(
    navController: NavHostController,
    THViewModel: THViewModel
) {
    val navEvent by THViewModel.navEvent.collectAsStateWithLifecycle()

    LaunchedEffect(navEvent) {
        navEvent?.let {event ->
            when (event) {
                NavigationEvent.NavigateToStart -> navController.navigate("start") {
                    popUpTo("permissions") { inclusive = true }
                }
                //NavigationEvent.NavigateToStart -> navController.navigate("start") {popUpTo("start") {inclusive = true} }
                NavigationEvent.NavigateToClue -> navController.navigate("clue")
                NavigationEvent.NavigateToClueSolved -> navController.navigate("clueSolved")
                NavigationEvent.NavigateToTHCompleted -> navController.navigate("thCompleted") { popUpTo("start") {inclusive = true} }
            }
            THViewModel.onNavigationEventHandled()
        }
    }

    NavHost(
        navController = navController,
        startDestination = "permissions",
        enterTransition = { fadeIn(animationSpec = tween(durationMillis = 300)) },
        exitTransition = { fadeOut(animationSpec = tween(durationMillis = 300))}) {
        composable("permissions",
            enterTransition = { fadeIn(animationSpec = tween(durationMillis = 300)) },
            exitTransition = { fadeOut(animationSpec = tween(durationMillis = 300)) }
        ) {
            PermissionsScreen(
                viewModel = THViewModel,
                onNavigateToStart = {
                    navController.navigate("start") {
                        popUpTo("permissions") {inclusive = true }
                    }
                }
            )
        }
        composable("start",
            enterTransition = { fadeIn(animationSpec = tween(durationMillis = 300)) },
            exitTransition = { fadeOut(animationSpec = tween(durationMillis = 300)) }
        ) {
            StartScreen(viewModel = THViewModel)
        }
        composable("clue",
            enterTransition = { fadeIn(animationSpec = tween(durationMillis = 300)) },
            exitTransition = { fadeOut(animationSpec = tween(durationMillis = 300)) }
        ) {
            ClueScreen(viewModel = THViewModel)
        }
        composable("clueSolved",
            enterTransition = { fadeIn(animationSpec = tween(durationMillis = 300)) },
            exitTransition = { fadeOut(animationSpec = tween(durationMillis = 300)) }
        ) {
            FoundItScreen(viewModel = THViewModel)
        }
        composable("thCompleted",
            enterTransition = { fadeIn(animationSpec = tween(durationMillis = 300)) },
            exitTransition = { fadeOut(animationSpec = tween(durationMillis = 300)) }
        ) {
            VictoryScreen(viewModel = THViewModel)
        }
    }
}