package com.example.mobiletreasurehunt

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.mobiletreasurehunt.navigation.TreasureHuntNavGraph
import com.example.mobiletreasurehunt.ui.theme.MobileTreasureHuntTheme
import com.example.mobiletreasurehunt.viewmodel.THViewModel

/*
1. Benjamin Leonard
2. OSU
3. CS 492
 */

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MobileTreasureHuntTheme {
                val THViewModel: THViewModel = viewModel(this)
                val navController = rememberNavController()

                TreasureHuntNavGraph(
                    navController = navController,
                    THViewModel = THViewModel
                )
            }
        }
    }
}